﻿using System;
using System.Linq;
using System.Collections.Generic;
namespace Card
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] cards = {
                1, 2,3,4,5,6,7,8,9,10
            };

            var r = new Random();
            var shuffle = cards.OrderBy(card => r.Next());
            
            int a = 0, b = 0,cnt=0,rem=0;
            for (int i = 0; i < 2; i++)
            {
                if (cnt == 0)
                {
                    cnt = r.Next(40);
                    Console.Write("Player {0} :", i + 1 + " (" + cnt + ")");
                }
                else
                {
                    rem = 40 - cnt;
                    Console.Write("Player {0} :", i + 1 + " (" + rem + ")");
                }
                //var r1 = shuffle.Skip(1 * i);
                string a2 = string.Join(" ,", (shuffle.Skip(1 * i).Take(1)));
                
                // Console.WriteLine(string.Join(" ,", (shuffle.Skip(1 * i).Take(1))));
                Console.WriteLine(a2);
                if (a == 0)
                {
                    a = Convert.ToInt32(a2);
                }
                else
                {
                    b = Convert.ToInt32(a2);
                }
            }
            if (a > b)
            {
                Console.WriteLine("Player 1 win this round");
            }
            else if (a < b)
            {
                Console.WriteLine("Player 2 win this round");
            }
            else
            {
                Console.WriteLine("No winner in this round");
            }

            Console.WriteLine();
            Console.ReadLine();
        
            
        }
    }
}
